package com.sanyrp.launcher

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.playButton).setOnClickListener {
            Toast.makeText(this, "Подключение к SAN-CITY\n188.127.241.74:1612", Toast.LENGTH_SHORT).show()
        }
    }
}
